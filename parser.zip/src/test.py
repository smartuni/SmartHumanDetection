import client as mqttsn

# MQTT Data

MQTT_CLIENT_ID = "parser"
MQTT_HOST = "192.168.1.169"
MQTT_PORT = 1883

# Mapping der Topics
mapping_sn_to_cayenne = {"publisher/roomSensorInformation/Sensor1": 1, "publisher/roomSensorInformation/Sensor2": 2, 3 : "subscriber/light"}
mapping_cayenne_to_sn = {1: "subscriber/light"}


class MyCallback(mqttsn.Callback):

    def __init__(self, mapping):
        self.events = []
        self.registered = {}
        self.mapping = mapping

    def message_arrived(self, topic_name, payload, qos, retained, msgid):
        print(f'{self} | topic_name: {topic_name} | payload: {payload} | '
              f'qos {qos} | retained {retained} | msgid {msgid}',
              file=sys.stderr)
        if topic_name in self.mapping:
            topic = self.mapping[topic_name]
            # self.cayenne.virtualWrite(topic,payload)
        else:
            print(f'unknown topic{topic_name}')

        return True


# Verbindung mit dem MQTTSN-Broker aufbauen
mqttsn_client = mqttsn.Client(host=MQTT_HOST, port=MQTT_PORT)
mqttsn_client.register_callback(MyCallback(mapping_sn_to_cayenne))
mqttsn_client.connect()


mqttsn_client.publish(1, "1")
print("läuft?")
