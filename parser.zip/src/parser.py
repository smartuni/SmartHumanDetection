import MQTTSNclient as mqttsn
import cayenne.client as cayenne
import csv
import sys
from time import sleep
from thread import start_new_thread

cayenne_topic_file = "cayenne.csv"
mqttsn_topic_file = "mqttsn.csv"

# Cayenne Data
CAYENNE_USERNAME = "6973b880-cad0-11e8-a7e6-57c1c5bda2a3"
CAYENNE_CLIENT_ID = "0f48bc30-d056-11e8-a254-e163efaadfe8"

#CAYNNE_TOPIC_START_DATA = "v1/M6973b880-cad0-11e8-a7e6-57c1c5bda2a3/things/cd8e4fd0-d05a-11e8-898f-c12a468aadce/data/"

#CAYNNE_TOPIC_START_RESPONSE = "v1/M6973b880-cad0-11e8-a7e6-57c1c5bda2a3/things/cd8e4fd0-d05a-11e8-898f-c12a468aadce/response/"

#CAYNNE_TOPIC_START_COMMAND = "v1/M6973b880-cad0-11e8-a7e6-57c1c5bda2a3/things/cd8e4fd0-d05a-11e8-898f-c12a468aadce/cmd/"

# MQTT Data
MQTT_CLIENT_ID = "parser"
MQTT_PORT = 1883

# Mapping der Topics
mapping_sn_to_cayenne = {}
mapping_cayenne_to_sn = {}
mapping_sn_to_id = {}

def reconnect(client):
    while(True):
        sleep(15000)
        client.disconnect()
        sleep(300)
        client.connect()

# The callback for when a message is received from Cayenne.
def on_message(message):
    # mapping_cayenne_to_sn = {1: "subscriber/light"}
    print("message received: " + str(message))
    message_channel = message.channel
    message_topic = message.topic
    message_id = message.msg_id
    message_payload = message.value

    if (message_topic == 'cmd'):
        topic_mes = mapping_cayenne_to_sn[message_channel]
        topic_id_out = mapping_sn_to_id[topic_mes]
        mqttsn_client.publish(topic=topic_id_out, payload=message_payload, qos=1, retained=True)
        print "send message: ", topic_mes,topic_id_out,message_payload
    else:
        print("wrongt")
    # If there is an error processing the message return an error string, otherwise return nothing.

#Callback on MQTTSN
class MyCallback(mqttsn.Callback):

    def __init__(self, cayenne_client, mapping,mapping_id_to_topic):
        self.events = []
        self.registered = {}
        self.cayenne = cayenne_client
        self.mapping = mapping
        self.mapping_id_to_topic = mapping_id_to_topic

    def messageArrived(self, topicName, payload, qos, retained, msgid):
        print("\n\nNew MQTTSN message")
        print payload
        #print topicName
        #print self.mapping_id_to_topic
        print "Infos der Nachricht ",self.mapping_id_to_topic,topicName, payload
        if topicName in self.mapping_id_to_topic:
            topic_name = mapping_sn_to_id[topicName]
        else:
            topic_name = topicName
        if topic_name in self.mapping:
            topic = self.mapping[topic_name]
            #print("Topic gefunden")
            self.cayenne.virtualWrite(topic, payload)
            #print("An Cayenne gesendet")


        print "\n\n\n"

        return True


# Einstellungen laden
with open(mqttsn_topic_file) as mqtt_file:
    reader = csv.reader(mqtt_file, delimiter=';')
    for row in reader:
        mapping_sn_to_cayenne[row[0]] = int(row[1])

with open(cayenne_topic_file) as cayenne_file:
    reader = csv.reader(cayenne_file, delimiter=';')
    for row in reader:
        mapping_cayenne_to_sn[int(row[0])] = row[1]

if len(sys.argv) < 2:
    print "Es muessen die Parameter Cayenne-Password und RSMB-HOST uebergeben werden"
else:
    #Einlesen der Daten
    CAYENNE_PASSWORD = sys.argv[1]
    MQTT_HOST = sys.argv[2]
    # Verbindung mit der Cayenne-Cloud aufbauen
    cayenne_client = cayenne.CayenneMQTTClient()
    cayenne_client.on_message = on_message
    cayenne_client.begin(CAYENNE_USERNAME, CAYENNE_PASSWORD, CAYENNE_CLIENT_ID)
    cayenne_client.loop()

    # Verbindung mit dem MQTTSN-Broker aufbauen
    mqttsn_client = mqttsn.Client(clientid=MQTT_CLIENT_ID, host=MQTT_HOST, port=MQTT_PORT)
    callback = MyCallback(cayenne_client, mapping_sn_to_cayenne,mapping_sn_to_id)
    mqttsn_client.registerCallback(callback)
    mqttsn_client.connect()

    for topic in mapping_sn_to_cayenne:
        rc, id = mqttsn_client.subscribe(topic)
        mapping_sn_to_id[topic] = id
        mapping_sn_to_id[id] = topic

    for topic_cayenne in mapping_cayenne_to_sn:
        topic_mqtt = mapping_cayenne_to_sn[topic_cayenne]
        rc, id = mqttsn_client.subscribe(topic_mqtt)
        mapping_sn_to_id[topic_mqtt] = id
        mapping_sn_to_id[id] = topic_mqtt

    print("laeuft?")
    print mapping_sn_to_id

    start_new_thread(reconnect,(mqttsn_client,))

    cayenne_client.loop_forever()





